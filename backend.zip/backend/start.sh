#!/bin/bash

# Set Node.js memory limits
export NODE_OPTIONS="--max-old-space-size=512"

# Set environment variables
export NODE_ENV=production
export PORT=3000

# Start the application
echo "🚀 Starting Code Editor Backend..."
echo "💾 Memory limit: 512MB"
echo "🔧 Environment: $NODE_ENV"
echo "🌐 Port: $PORT"

# Start the server
node index.js
